package com.example.tolgahanalbayram.learnfragment;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class ApiManager {

    private static ApiManager instance = new ApiManager();
    private static ApiInterface apiInterface;
    private static final String APIURL = "https://allsportsapi.com";
    private static final String APIkey = "c188a2f376bab3e91b83aa42975af12905361a9879b767e08dd93635049979ce";
    private static final String methodName = "Countries";

    public static ApiManager getInstance() {
        if (instance == null) {
            instance = new ApiManager();
        }
        if (apiInterface == null) {
            createApiInterface();
        }
        return instance;
    }


    private static void createApiInterface() {

        try {
            Retrofit retrofit = new Retrofit.Builder().baseUrl(APIURL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            apiInterface = retrofit.create(ApiInterface.class);

        } catch (Exception e) {
            System.out.println("Bağlandı");
        }


    }


    public Call<Countries> callCountries() {
        return apiInterface.countries(methodName, APIkey);
    }


}
