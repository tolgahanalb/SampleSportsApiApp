package com.example.tolgahanalbayram.learnfragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertController;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class BlankFragment extends Fragment {

    @BindView(R.id.r_view)
    RecyclerView recyclerView;

    @BindView(R.id.tv1)
    TextView textView;
Button button ;
Boolean a ;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_blank, container, false);
        ButterKnife.bind(this,v);

        return v;
    }


    @OnClick(R.id.button_to_f3)
    public void clickf2Button (){
        //        BlankFragment2 fragment2 = new BlankFragment2();
        //        ((MainActivity) (getActivity())).replace(fragment2);

        Call<Countries> callCountries = ApiManager.getInstance().callCountries();
        callCountries.enqueue(new Callback<Countries>() {
            @Override
            public void onResponse(@NonNull Call<Countries> call, @NonNull Response<Countries> response) {
                List<Result> result = response.body().getResults();
                if (result != null ){
                    Log.i("Basarili", result.get(0).getCountry_name());
                    textView.setText(result.get(1).getCountry_name());
                    
                }
            }

            @Override
            public void onFailure(@NonNull Call<Countries> call, @NonNull Throwable t) {
                Log.i("Basarisiz", t.getMessage());
            }
        });

    }
}
