package com.example.tolgahanalbayram.learnfragment;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("api/football")
    Call<Countries> countries(@Query("met") String met, @Query("APIkey") String APIkey);

}
