package com.example.tolgahanalbayram.learnfragment;

import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class MainActivity extends AppCompatActivity {
ApiInterface apiInterface;
//ApiManager apiManager;
    FragmentManager manager = getSupportFragmentManager();

    public int a = manager.getBackStackEntryCount();
    public String aa;
    private ArrayList<Result> data =null;
    private static final String APIURL = "https://allsportsapi.com/";
    BlankFragment2 fragment2 = new BlankFragment2();
    BlankFragment fragment = new BlankFragment();

//    AppCompatImageView backButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        android.support.v7.widget.Toolbar toolbar;
        toolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);


        Call<Countries> callCountries = ApiManager.getInstance().callCountries();
        callCountries.enqueue(new Callback<Countries>() {
            @Override
            public void onResponse(@NonNull Call<Countries> call, @NonNull Response<Countries> response) {
                List<Result> result = response.body().getResults();
                if (result != null ){
                    Log.i("Basarili", result.get(0).getCountry_name());
                }
            }

            @Override
            public void onFailure(@NonNull Call<Countries> call, @NonNull Throwable t) {
                Log.i("Basarisiz", t.getMessage());
            }
        });

       replace(fragment);






//        getSupportFragmentManager().beginTransaction().add(R.id.main_frame,fragment).commit();

    }


    //
//    @OnClick(R.id.button_to_f3)
//    public void f3ButtonClickListener (View view){
//        BlankFragment2 fragment2 = new BlankFragment2();
//
//        replace(fragment2);
//    }
    @OnClick(R.id.back_button)
    void backOnClick() {
        if (manager.getBackStackEntryCount() != 1) {
            onBackPressed();
        } else if (manager.getBackStackEntryCount() == 1) {
            finish();
        }
    }


    public void replace(Fragment newFragment) {

        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.main_frame, newFragment, newFragment.getClass().getName());
        transaction.addToBackStack(null);
        transaction.commit();
    }

}
